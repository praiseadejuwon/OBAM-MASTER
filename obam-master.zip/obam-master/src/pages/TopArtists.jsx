const TopArtists = () => <div>TopArtists</div>;

export default TopArtists;
