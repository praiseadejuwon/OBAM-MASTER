import React from 'react';

const CountryTracks = () => <div>CountryTracks</div>;

export default CountryTracks;
