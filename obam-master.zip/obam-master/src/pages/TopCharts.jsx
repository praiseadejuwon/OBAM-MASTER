const TopCharts = () => <div>TopCharts</div>;

export default TopCharts;
