const ArtistDetails = () => (
  <div>ArtistDetails</div>
);

export default ArtistDetails;
