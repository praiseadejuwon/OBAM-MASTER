const SongDetails = () => <div>SongDetails</div>;

export default SongDetails;
