const Search = () => (
  <div>Search</div>
);

export default Search;
