import React from 'react';

const Error = () => (
  <div>Error</div>
);

export default Error;
