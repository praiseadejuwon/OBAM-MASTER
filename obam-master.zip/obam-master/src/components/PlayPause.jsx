const PlayPause = () => (
  <div>Loader</div>
);

export default PlayPause;
